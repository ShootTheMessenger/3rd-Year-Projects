<?php
session_start();

// Include database connection
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Fetch user information from the database
$sql = "SELECT * FROM proj_applicant WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Assign retrieved data to variables
    $surname = $row['surname'];
    $first_name = $row['first_name'];
    $dob = $row['dob'];
    $nationality = $row['nationality'];
    $omang_passport = $row['omang_passport'];
    $phone_number = $row['phone_number'];
    $email = $row['email'];
    $address = $row['address'];
    $postal_code = $row['postal_code'];
    $street = $row['street'];
    $city = $row['city'];
    $country = $row['country'];
} else {
    // Handle error if user not found
    echo "User not found";
}
$stmt->close();
$conn->close();
?>
