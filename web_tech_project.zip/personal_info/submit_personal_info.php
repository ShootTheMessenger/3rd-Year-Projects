<?php
session_start();

// Include database connection
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$surname = $_POST['surname'];
$first_name = $_POST['first_name'];
$dob = $_POST['dob'];
$nationality = $_POST['nationality'] ?? '';
$omang_passport = $_POST['omang_passport'] ?? '';
$phone_number = $_POST['phone_number'] ?? '';
$email = $_POST['email'] ?? '';
$address = $_POST['address'] ?? '';
$postal_code = $_POST['postal_code'];
$street = $_POST['street'] ?? '';
$city = $_POST['city'] ?? '';
$country = $_POST['country'] ?? '';

// Update the user's record
$username = $_SESSION["username"];
$stmt_update = $conn->prepare("UPDATE proj_applicant SET surname = ?, first_name = ?, dob = ?, nationality = ?, omang_passport = ?, phone_number = ?, email = ?, address = ?, postal_code = ?, street = ?, city = ?, country = ? WHERE username = ?");
$stmt_update->bind_param("sssssssssssss", $surname, $first_name, $dob, $nationality, $omang_passport, $phone_number, $email, $address, $postal_code, $street, $city, $country, $username);

if ($stmt_update->execute()) {
    $message = "Personal information updated successfully.";
} else {
    $message = "Error updating personal information: " . $stmt_update->error;
}

// Redirect back to personal information form
header("Location: personal_information_form.php?message=" . urlencode($message));
exit();
?>
