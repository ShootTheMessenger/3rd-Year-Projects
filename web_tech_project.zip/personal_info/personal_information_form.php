<?php
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
        <link rel="stylesheet" href="../styles/familystyles.css">
        <title>Personal Information</title>
    </head>

    <body>
        <div class="wrapper">

            <!-- navigation bar starts here -->
            <div class="sidebar">
                <h2>UB Online Application</h2>
                <ul>
                    <li><a href="../home/stud_home.php"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
                    <li class="active"><a href="../personal_info/personal_information_form.php"><i class="fas fa-user"></i><p class="text">Personal Information</p></a></li>
                    <li><a href="../family_info/family_form.php"><i class="fas fa-users"></i><p class="text">Next of Kin</p></a></li>
                    <li><a href="../study_choices/study_choices.php"><i class="fas fa-graduation-cap"></i><p class="text">Study Choices</p></a></li>
                    <li><a href="../grades/secondary_education.php"><i class="fas fa-school"></i><p class="text">Secondary Education</p></a></li>
                    <li><a href="../uploadTable/uploadTable.php"><i class="fas fa-id-card"></i><p class="text">Documentation</p></a></li>
                    <li><a href="../submit/submit_application.php"><i class="fas fa-check"></i><p class="text">Submit Application</p></a></li>
                </ul>
            </div>
            <!-- Navigation bar ends here -->

            <!-- Page contents start here -->
            <div class="main-content">

                <div class="header">
                    <div class="text">Welcome to the UB Portal</div>
                    <div class="bottom-btn">
                        <a href="#"><i class="fas fa-bell"></i></a>
                        <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>

                <!-- Personal information bar starts here -->
                <div class="info">
                    <div class="content-bar">
                        <div class="content-title">Personal Information</div>
                        <div class="details">
                            <form method="post" action="submit_personal_info.php">
                                <?php include 'fetch_personal_info.php'; ?>
                                <label for="surname">Last Name: </label>
                                <input type="text" name="surname" value="<?php echo isset($surname) ? $surname : ''; ?>"><br><br>
                                <label for="fnames">First Name(s): </label>
                                <input type="text" name="first_name" value="<?php echo isset($first_name) ? $first_name : ''; ?>"><br><br>
                                <label for="dob">Date of Birth: </label>
                                <input type="date" name="dob" value="<?php echo isset($dob) ? $dob : ''; ?>"><br><br>
                                <label for="nationality">Nationality: </label>
                                <input type="text" name="nationality" value="<?php echo isset($nationality) ? $nationality : ''; ?>"><br><br>
                                <label for="omang_passport">Omang/Passport number: </label>
                                <input type="text" name="omang_passport" value="<?php echo isset($omang_passport) ? $omang_passport : ''; ?>"><br><br>
                                <label for="phone_number">Cellphone/Telephone number: </label>
                                <input type="tel" name="phone_number" value="<?php echo isset($phone_number) ? $phone_number : ''; ?>"><br><br>
                                <label for="email">Email: </label>
                                <input type="email" name="email" value="<?php echo isset($email) ? $email : ''; ?>"><br><br>
                                <label for="address">Physical Address: </label>
                                <input type="text" name="address" value="<?php echo isset($address) ? $address : ''; ?>"><br><br>
                                <label for="postal_code">Postal Code: </label>
                                <input type="text" name="postal_code" value="<?php echo isset($postal_code) ? $postal_code : ''; ?>"><br><br>
                                <label for="street">Street Name: </label>
                                <input type="text" name="street" value="<?php echo isset($street) ? $street : ''; ?>"><br><br>
                                <label for="city">Town/City: </label>
                                <input type="text" name="city" value="<?php echo isset($city) ? $city : ''; ?>"><br><br>
                                <label for="country">Country of Residence: </label>
                                <input type="text" name="country" value="<?php echo isset($country) ? $country : ''; ?>"><br><br>
                                
                                <input type="submit" id="submit" name="submit" value="Submit"><?php echo $message; ?><br><br>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Personal information bar ends here -->
            </div>
        </div>
    </body>
    <!-- Page contents end here -->
</html>