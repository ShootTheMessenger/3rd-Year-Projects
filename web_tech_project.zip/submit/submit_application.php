<?php
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
        <link rel="stylesheet" href="../styles/homestyles.css">
        <title>Submit Application</title>
    </head>

    <body>
        <div class="wrapper">

            <!-- navigation bar starts here -->
            <div class="sidebar">
                <h2>UB Online Application</h2>
                <ul>
                    <li><a href="../home/stud_home.php"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
                    <li><a href="../personal_info/personal_information_form.php"><i class="fas fa-user"></i><p class="text">Personal Information</p></a></li>
                    <li><a href="../family_info/family_form.php"><i class="fas fa-users"></i><p class="text">Next of Kin</p></a></li>
                    <li><a href="../study_choices/study_choices.php"><i class="fas fa-graduation-cap"></i><p class="text">Study Choices</p></a></li>
                    <li><a href="../grades/secondary_education.php"><i class="fas fa-school"></i><p class="text">Secondary Education</p></a></li>
                    <li><a href="../uploadTable/uploadTable.php"><i class="fas fa-id-card"></i><p class="text">Documentation</p></a></li>
                    <li class="active"><a href="../submit/submit_application.php"><i class="fas fa-check"></i><p class="text">Submit Application</p></a></li>
                </ul>
            </div>
            <!-- navigation bar ends here -->

            <!-- page content starts here -->
            <div class="main-content">
                <div class="header">
                    <div class="text">Welcome to the UB Portal</div>
                    <div class="bottom-btn">
                        <a href="#"><i class="fas fa-bell"></i></a>
                        <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>

                <div class="info">

                    <!-- personal information bar starts here -->
                    <div class="content-bar">
                        <div class="content-title">Submit Application</div>
                        <div class="details">
                            <div class="user-info">
                                <input type="submit" name="ranking" value="Submit Your Application"> 
                            </div>
                        </div>
            
                    </div>
                    <!-- personal information bar ends here -->
                    
                </div>
            </div>
            <!-- page content ends here -->

        </div>

        

    </body>
</html>