<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = isset($_GET['message']) ? $_GET['message'] : '';
$message1 = isset($_GET['message1']) ? $_GET['message1'] : '';
$message2 = isset($_GET['message2']) ? $_GET['message2'] : '';
$message3 = isset($_GET['message3']) ? $_GET['message3'] : '';
$message4 = isset($_GET['message4']) ? $_GET['message4'] : '';
$message5 = isset($_GET['message5']) ? $_GET['message5'] : '';
$message6 = isset($_GET['message6']) ? $_GET['message6'] : '';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
        <link rel="stylesheet" href="../styles/uploadtable.css">
        <title>Documentation</title>

        <style>
            /* Card layout for documents */
            .document-card {
                background-color: #fff;
                border-radius: 8px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                padding: 20px;
                margin-bottom: 20px;
            }
            .document-card a {
                color: #007bff;
                text-decoration: none;
            }
            .document-card button {
                background-color: #750f1a;
                color: #fff;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                cursor: pointer;
                transition: background-color 0.3s;
            }
            .document-card button:hover {
                background-color: #0056b3;
            }
            /* Styling for file input */
            .file-input {
                margin-top: 10px;
                display: flex;
                align-items: center;
            }
            .file-input input[type="file"] {
                display: none;
            }
            .file-input label {
                background-color: #007bff;
                color: #fff;
                padding: 10px 20px;
                border-radius: 4px;
                cursor: pointer;
                transition: background-color 0.3s;
            }
            .file-input label:hover {
                background-color: #0056b3;
            }
            .file-input label::after {
                content: 'Select File';
            }
            /* Style for submit button */
            .file-submit button {
                background-color: #4CAF50;
                color: #fff;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                cursor: pointer;
                transition: background-color 0.3s;
            }
            .file-submit button:hover {
                background-color: #45a049;
            }
        </style>

    <body>
        <div class="wrapper">

            <!-- navigation bar starts here -->
            <div class="sidebar">
                <h2>UB Online Application</h2>
                <ul>
                    <li><a href="../home/stud_home.php"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
                    <li><a href="../personal_info/personal_information_form.php"><i class="fas fa-user"></i><p class="text">Personal Information</p></a></li>
                    <li><a href="../family_info/family_form.php"><i class="fas fa-users"></i><p class="text">Next of Kin</p></a></li>
                    <li><a href="../study_choices/study_choices.php"><i class="fas fa-graduation-cap"></i><p class="text">Study Choices</p></a></li>
                    <li><a href="../grades/secondary_education.php"><i class="fas fa-school"></i><p class="text">Secondary Education</p></a></li>
                    <li class="active"><a href="../uploadTable/uploadTable.php"><i class="fas fa-id-card"></i><p class="text">Documentation</p></a></li>
                    <li><a href="../submit/submit_application.php"><i class="fas fa-check"></i><p class="text">Submit Application</p></a></li>
                </ul>
            </div>
            <!-- Navigation bar ends here -->

            <!-- Page contents start here -->
            <div class="main-content">

                <div class="header">
                    <div class="text">Welcome to the UB Portal</div>
                    <div class="bottom-btn">
                        <a href="#"><i class="fas fa-bell"></i></a>
                        <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>

                <!-- Upload table start here-->
                <div class="info">
                    <div class="content-bar">
                        <div class="content-title">Upload Documents</div>
                        <div class="details">
                            <div class="table-container">
                                <div class="document-card">
                                    <h3>National ID</h3>
                                    <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                    <form action="file_handler.php" method="post" enctype="multipart/form-data">
                                        <input type="file" name="file_national_id" id="fileInput">
                                        <button type="submit" name="submit_national_id">Upload</button>
                                        <?php echo "<p>$message</p>"; ?>
                                    </form>
                               </div>
                               <div class="document-card">
                                <h3>Passport</h3>
                                <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                <form action="file_handler1.php" method="post" enctype="multipart/form-data">
                                    <input type="file" name="file_passport" id="fileInput">
                                    <button type="submit" name="submit_passport">Upload</button>
                                    <?php echo "<p>$message1</p>"; ?>
                                </form>
                               </div>
                               <div class="document-card">
                                <h3>Proof of Name Change</h3>
                                <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                <form action="file_handler2.php" method="post" enctype="multipart/form-data">
                                    <input type="file" name="file_name_change" id="fileInput">
                                    <button type="submit" name="submit_name_change">Upload</button>
                                    <?php echo "<p>$message2</p>"; ?>
                                </form>
                                </div>
                                <div class="document-card">
                                    <h3>Parent Tax Certificate</h3>
                                    <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                    <form action="file_handler3.php" method="post" enctype="multipart/form-data">
                                        <input type="file" name="file_tax" id="fileInput">
                                        <button type="submit" name="submit_tax">Upload</button>
                                        <?php echo "<p>$message3</p>"; ?>
                                    </form>
                               </div>
                               <div class="document-card">
                                <h3>Parent Payslip</h3>
                                <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                <form action="file_handler4.php" method="post" enctype="multipart/form-data">
                                    <input type="file" name="file_payslip" id="fileInput">
                                    <button type="submit" name="submit_payslip">Upload</button>
                                    <?php echo "<p>$message4</p>"; ?>
                                </form>
                               </div>
                               <div class="document-card">
                                <h3>Parent Resident Permit</h3>
                                <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                <form action="file_handler5.php" method="post" enctype="multipart/form-data">
                                    <input type="file" name="file_permit" id="fileInput">
                                    <button type="submit" name="submit_permit">Upload</button>
                                    <?php echo "<p>$message5</p>"; ?>
                                </form>
                                </div>
                                <div class="document-card">
                                <h3>Academic Documents</h3>
                                <p><a href="#" onclick="viewFile('nationalID')">View</a></p>
                                <form action="file_handler6.php" method="post" enctype="multipart/form-data">
                                    <input type="file" name="file_document" id="fileInput">
                                    <button type="submit" name="submit_document">Upload</button>
                                    <?php echo "<p>$message6</p>"; ?>
                                </form>
                           </div>
                    </div>
                </div>
                
                    <!-- JavaScript function to handle file viewing -->
                    <script>
                        function viewFile(fileName) {
                            // Replace this with your logic to view the file
                            alert("Viewing file: " + fileName);
                        }

                          </script>
                <!-- Upload tavle ends here -->
            </div>
        </div>
    </body>
    <!-- Page contents end here -->
</html>