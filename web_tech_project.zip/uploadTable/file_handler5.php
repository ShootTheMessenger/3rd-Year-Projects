<?php
session_start();

// Database configuration
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];
$message5 = "";

if (isset($_POST["submit_permit"])) {
    // Get applicant ID
    $applicant_id = "";
    $stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
    $stmt_applicant_id->bind_param("s", $username);
    $stmt_applicant_id->execute();
    $result_applicant_id = $stmt_applicant_id->get_result();

    if ($result_applicant_id->num_rows > 0) {
        $row = $result_applicant_id->fetch_assoc();
        $applicant_id = $row['id'];
    }

    $stmt_applicant_id->close();

    // Check if file already exists for the user
    $stmt_check_id = $conn->prepare("SELECT * FROM proj_documents WHERE applicant_id = ? AND document_type = 'Permit'");
    $stmt_check_id->bind_param("i", $applicant_id);
    $stmt_check_id->execute();
    $result_check_id = $stmt_check_id->get_result();

    if ($result_check_id->num_rows > 0) {
        $message5 = "You have already uploaded a Permit file.";
    } else {
        // File information
        $filename = $_FILES["file_permit"]["name"];
        $filetype = $_FILES["file_permit"]["type"];
        $fileTmpName = $_FILES["file_permit"]["tmp_name"];
        $fileError = $_FILES["file_permit"]["error"];
        $upload_date = date("Y-m-d");

        // Check if file was uploaded without errors
        if ($fileError === 0) {
            // Move the uploaded file to a permanent location
            $uploadDir = "uploads/";

            if (!is_dir($uploadDir)) {
                // Create the directory if it doesn't exist
                if (!mkdir($uploadDir, 0777, true)) {
                    die("Failed to create upload directory: " . $uploadDir);
                }
            }

            // Check if the directory is writable
            if (!is_writable($uploadDir)) {
                die("Upload directory is not writable.");
            }

            $filename = preg_replace("/[^a-zA-Z0-9.]/", "_", $filename); //sanitize filename
            $filePath = $uploadDir . basename($filename);
            if (move_uploaded_file($fileTmpName, $filePath)) {
                // Insert file information into database
                $document_type = "Permit";
                $sql = "INSERT INTO proj_documents (applicant_id, document_type, file_name, file_type, upload_date) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("issss", $applicant_id, $document_type, $filename, $filetype, $upload_date);

                if ($stmt->execute()) {
                    $message5 = "File uploaded successfully.";
                } else {
                    $message5 = "Error inserting file information into database.";
                }
                $stmt->close();
            } else {
                $message5 = "Error moving uploaded file.";
            }
        } else {
            $message5 = "Error uploading file.";
        }
    }
} else {
    $message5 = "No file submitted.";
}

// Close database connection
$conn->close();

// Redirect back to the upload table page with a message
header("Location: ../uploadTable/uploadTable.php?message5=" . urlencode($message5));
exit();
?>
