<?php
session_start();

// Database configuration
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];
$message6 = "";

if (isset($_POST["submit_document"])) {
    // Get applicant ID
    $applicant_id = "";
    $stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
    $stmt_applicant_id->bind_param("s", $username);
    $stmt_applicant_id->execute();
    $result_applicant_id = $stmt_applicant_id->get_result();

    if ($result_applicant_id->num_rows > 0) {
        $row = $result_applicant_id->fetch_assoc();
        $applicant_id = $row['id'];
    }

    $stmt_applicant_id->close();

    // Check if file already exists for the user
    $stmt_check_id = $conn->prepare("SELECT * FROM proj_documents WHERE applicant_id = ? AND document_type = 'Academic Document'");
    $stmt_check_id->bind_param("i", $applicant_id);
    $stmt_check_id->execute();
    $result_check_id = $stmt_check_id->get_result();

    if ($result_check_id->num_rows > 0) {
        $message6 = "You have already uploaded an Academic Document file.";
    } else {
        // File information
        $filename = $_FILES["file_document"]["name"];
        $filetype = $_FILES["file_document"]["type"];
        $fileTmpName = $_FILES["file_document"]["tmp_name"];
        $fileError = $_FILES["file_document"]["error"];
        $upload_date = date("Y-m-d");

        // Check if file was uploaded without errors
        if ($fileError === 0) {
            // Move the uploaded file to a permanent location
            $uploadDir = "uploads/";

            if (!is_dir($uploadDir)) {
                // Create the directory if it doesn't exist
                if (!mkdir($uploadDir, 0777, true)) {
                    die("Failed to create upload directory: " . $uploadDir);
                }
            }

            // Check if the directory is writable
            if (!is_writable($uploadDir)) {
                die("Upload directory is not writable.");
            }

            $filename = preg_replace("/[^a-zA-Z0-9.]/", "_", $filename); //sanitize filename
            $filePath = $uploadDir . basename($filename);
            if (move_uploaded_file($fileTmpName, $filePath)) {
                // Insert file information into database
                $document_type = "Academic Document";
                $sql = "INSERT INTO proj_documents (applicant_id, document_type, file_name, file_type, upload_date) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("issss", $applicant_id, $document_type, $filename, $filetype, $upload_date);

                if ($stmt->execute()) {
                    $message6 = "File uploaded successfully.";
                } else {
                    $message6 = "Error inserting file information into database.";
                }
                $stmt->close();
            } else {
                $message6 = "Error moving uploaded file.";
            }
        } else {
            $message6 = "Error uploading file.";
        }
    }
} else {
    $message6 = "No file submitted.";
}

// Close database connection
$conn->close();

// Redirect back to the upload table page with a message
header("Location: ../uploadTable/uploadTable.php?message6=" . urlencode($message6));
exit();
?>
