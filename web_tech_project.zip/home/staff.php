<?php

session_start();

// Include database connection
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Prepare and bind the query
$stmt = $conn->prepare("SELECT first_name, surname, email FROM proj_staff WHERE username = ?");
$stmt->bind_param("s", $username);

// Execute the query
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, fetch data
    $row = $result->fetch_assoc();
    // Assign retrieved data to variables
    $name = $row['first_name'] . " " . $row['surname'];
    $email = $row['email'];
} else {
    // Handle error if user not found
    echo "User not found";
}

// Close prepared statement and database connection
$stmt->close();
$conn->close();
?>
