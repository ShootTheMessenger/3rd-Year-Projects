<?php
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
        <link rel="stylesheet" href="../styles/homestyles.css">
        <title>Admin Home</title>
    </head>

    <body>
        <div class="wrapper">

            <!-- navigation bar starts here -->
            <div class="sidebar">
                <h2>UB Online Application</h2>
                <ul>
                    <li class="active"><a href="#"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
                </ul>

            </div>
            <!-- navigation bar ends here -->

            <!-- page content starts here -->
            <div class="main-content">
                <div class="header">
                    <div class="text">Welcome to the UB Portal</div>
                    <div class="bottom-btn">
                        <a href="#"><i class="fas fa-bell"></i></a>
                        <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>

                <div class="info">

                    <!-- personal information bar starts here -->
                    <div class="content-bar">
                        <div class="content-title">Personal Information</div>
                        <div class="details">
                            <!-- <div class="user-image">
                                <img src="../img/profile.jpg" alt="profile pic">
                            </div> -->
                            <div class="user-info">
                                <?php include('admin.php'); ?>
                                <p><span>Name:</span> <?php echo $name; ?></p>
                                <p><span>Email:</span> <?php echo $email; ?></p>
                                <br>

                                <form method="post" action="">
                                    <input type="submit" name="ranking" value="Review Applications">
                                </form>   
                            </div>
                        </div>
            
                    </div>
                    <!-- personal information bar ends here -->
                    
                </div>
            </div>
            <!-- page content ends here -->

        </div>

        

    </body>
</html>