<?php

// Establish connection to your database
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Get staff ID
$staff_id = "";
$stmt_staff_id = $conn->prepare("SELECT id FROM proj_staff WHERE username = ?");
$stmt_staff_id->bind_param("s", $username);
$stmt_staff_id->execute();
$result_staff_id = $stmt_staff_id->get_result();

if ($result_staff_id->num_rows > 0) {
    $row = $result_staff_id->fetch_assoc();
    $staff_id = $row['id'];
}

$stmt_staff_id->close();

// SQL query to get points ranking for each course
$sql = "SELECT a.first_name, a.surname, a.points
        FROM proj_applicant a
        WHERE a.first_choice IN (
            SELECT pc.course_name FROM proj_courses pc WHERE pc.staff_id = $staff_id
        )
        OR a.second_choice IN (
            SELECT pc.course_name FROM proj_courses pc WHERE pc.staff_id = $staff_id
        )
        ORDER BY a.points DESC";

$result = $conn->query($sql);

$ranking = array();
if ($result->num_rows > 0) {
    // Store data in an array
    while($row = $result->fetch_assoc()) {
        $ranking[] = $row;
    }
} else {
    $message = "0 results";
}

$conn->close();

// Redirect to staff home with ranking message
header("Location: ../home/staff_home.php?ranking=" . urlencode(json_encode($ranking)));
exit();
?>
