<?php
// Establish connection to your database
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate and sanitize form inputs
$first_name = $_POST["new_first_name"];
$surname = $_POST["new_surname"];
$email = $_POST["new_email"];
$username = $_POST["new_username"];
$password = $_POST["new_password"];

$message = "";
// Check if username already exists
$stmt_check_username = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
$stmt_check_username->bind_param("s", $username);
$stmt_check_username->execute();
$stmt_check_username->store_result();

if ($stmt_check_username->num_rows > 0) {
    $stmt_check_username->close();
    $conn->close();
    $message = "Username already exists";
    header("Location: login.php?message=" . urlencode($message));
    exit();
}

$stmt_check_username->close();

// Prepare and bind SQL statement
$stmt = $conn->prepare("INSERT INTO proj_applicant (username, password, email, first_name, surname) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $password, $email, $first_name, $surname);


// Execute the statement
if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    $message = "Account created successfully";
    header("Location: login.php?message=" . urlencode($message));
    exit();
} else {
    $stmt->close();
    $conn->close();
    $message = "Error creating account";
    header("Location: login.php?message=" . urlencode($message));
    exit();
}
?>
