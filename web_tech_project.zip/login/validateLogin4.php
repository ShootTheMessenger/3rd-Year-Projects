<?php
// Include database connection
session_start();

// connect to the database
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username and password from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Query to check if the user is an applicant
    $sql_applicant = "SELECT username, password FROM proj_applicant WHERE username = '$username' AND password = '$password'";
    $result_applicant = $conn->query($sql_applicant);

    // Query to check if the user is an admin
    $sql_admin = "SELECT username, password FROM proj_admin WHERE username = '$username' AND password = '$password'";
    $result_admin = $conn->query($sql_admin);

    // Query to check if the user is a staff member
    $sql_staff = "SELECT username, password FROM proj_staff WHERE username = '$username' AND password = '$password'";
    $result_staff = $conn->query($sql_staff);

    if ($result_applicant->num_rows > 0) {
        // User is an applicant
        $_SESSION["username"] = $username;
        header("Location: ../home/stud_home.php");
        exit();
    } elseif ($result_admin->num_rows > 0) {
        // User is an admin
        $_SESSION["username"] = $username;
        header("Location: ../home/admin_home.php");
        exit();
    } elseif ($result_staff->num_rows > 0) {
        // User is a staff member
        $_SESSION["username"] = $username;
        header("Location: ../home/staff_home.php");
        exit();
    } else {
        // Invalid credentials
        $_SESSION['error_message'] = "Invalid username or password";
        header("Location: login.php"); // Redirect back to login page
        exit();
    }
}
?>
