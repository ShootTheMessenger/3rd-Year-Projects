<?php
// Establish connection to your database
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = isset($_GET['message']) ? $_GET['message'] : '';

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="../styles/loginstyles.css">
        <title>Login</title>
    </head>
    
    <body>

        <!-- sign in form starts here -->
        <div class="container">
            <div class="signup-signin">
                <form action="validateLogin4.php" class="sign-in-form" method="post">

                    <h2 class="title">SIGN IN</h2>
                    
                    <div class="input-field">
                        <input type="text" placeholder="Username" name="username" required>
                    </div>

                    <div class="input-field">
                        <input type="password" placeholder="Password" name="password" required>
                    </div>

                    <input type="submit" value="Login" class="btn">

                    <p class="account-text">Don't have an account? <a href="#" id="sign-up-btn2"> Sign Up here</a></p>
                    <?php echo "<p>$message</p>"; ?>
                </form>

                <form action="validateSignUp.php" class="sign-up-form" method="post">

                    <h2 class="title">SIGN UP</h2>
                    
                    <div class="input-field">
                        <input type="text" placeholder="First Name" name="new_first_name" id="new_first_name" required>
                    </div>

                    <div class="input-field">
                        <input type="text" placeholder="Surname" name="new_surname" id="new_surname" required>
                    </div>

                    <div class="input-field">
                        <input type="email" placeholder="Email" name="new_email" id="new_email" required>
                    </div>

                    <div class="input-field">
                        <input type="text" placeholder="Username" name="new_username" id="new_username" required>
                    </div>

                    <div class="input-field">
                        <input type="password" placeholder="Password" name="new_password" id="new_password" required>
                    </div>

                    <input type="submit" id="submit" name="submit" value="Create Account" class="btn">

                    <p class="account-text">Already have an account? <a href="#" id="sign-in-btn2"> Sign in here</a></p>
                </form>
            </div>
            
            <div class="panels-container">
                
                <div class="panel left-panel">
                    <div class="content">
                        <h3>Already have an account?</h3>
                        <p>Sign in and proceed with your application. Take the next step towards securing your future.</p>
                        <button class="btn" id="sign-in-btn">Sign In</button>
                    </div>
                </div>

                <div class="panel right-panel">
                    <div class="content">
                        <h3>Don't have an account?</h3>
                        <p>Sign up now to become part of our esteemed community. Explore endless opportunities for growth, discovery, and success.</p>
                        <button class="btn" id="sign-up-btn">Sign Up</button>
                    </div>
                </div>
            
            </div>
        </div>

        <script src="../javascript/app.js"></script>
        <!-- sign in form ends here -->

        
    </body>
</html>