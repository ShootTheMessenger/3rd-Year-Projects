<?php

// remove session variables
session_unset();

// destroy session
session_destroy();

// redirect user to login page
header("Location: login.php");
exit;
?>