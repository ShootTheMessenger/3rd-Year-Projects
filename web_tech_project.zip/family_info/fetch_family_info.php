<?php
session_start();

// Include database connection
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the session
$username = $_SESSION["username"];

$applicant_id = "";
$stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
$stmt_applicant_id->bind_param("s", $username);
$stmt_applicant_id->execute();
$result_applicant_id = $stmt_applicant_id->get_result();

if ($result_applicant_id->num_rows > 0) {
    $row = $result_applicant_id->fetch_assoc();
    $applicant_id = $row['id'];
}

// Retrieve next of kin information for the user
$sql = "SELECT * FROM proj_nextOfKin WHERE applicant_id = '$applicant_id'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $applicant_id); // Assuming applicant_id is an integer
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Assign retrieved data to variables
    $firstname = $row['first_name'];
    $surname = $row['surname'];
    $nationality = $row['nationality'];
    $gender = $row['gender'];
    $relation = $row['relation'];
    $address = $row['address'];
    $phone = $row['phone'];
    $email = $row['email'];
    $postcode = $row['postcode'];
} else {
    // Initialize variables if no data found
    $firstname = '';
    $surname = '';
    $nationality = '';
    $gender = '';
    $relation = '';
    $address = '';
    $phone = '';
    $email = '';
    $postcode = '';
}

$stmt->close();
$conn->close();
?>
