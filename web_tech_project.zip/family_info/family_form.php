<?php
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
        <link rel="stylesheet" href="../styles/familystyles.css">
        <link rel="stylesheet" href="../styles/main.css">
        <title>Next of Kin</title>
    </head>

    <body>
        <div class="wrapper">

            <!-- navigation bar starts here -->
            <div class="sidebar">
                <h2>UB Online Application</h2>
                <ul>
                    <li><a href="../home/stud_home.php"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
                    <li><a href="../personal_info/personal_information_form.php"><i class="fas fa-user"></i><p class="text">Personal Information</p></a></li>
                    <li class="active"><a href="../family_info/family_form.php"><i class="fas fa-users"></i><p class="text">Next of Kin</p></a></li>
                    <li><a href="../study_choices/study_choices.php"><i class="fas fa-graduation-cap"></i><p class="text">Study Choices</p></a></li>
                    <li><a href="../grades/secondary_education.php"><i class="fas fa-school"></i><p class="text">Secondary Education</p></a></li>
                    <li><a href="../uploadTable/uploadTable.php"><i class="fas fa-id-card"></i><p class="text">Documentation</p></a></li>
                    <li><a href="../submit/submit_application.php"><i class="fas fa-check"></i><p class="text">Submit Application</p></a></li>
                </ul>
            </div>
            <!-- navigation bar ends here -->

            <!-- page content starts here -->
            <div class="main-content">
                <div class="header">
                    <div class="text">Welcome to the UB Portal</div>
                    <div class="bottom-btn">
                        <a href="#"><i class="fas fa-bell"></i></a>
                        <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>

                <div class="info">

                    <!-- personal information bar starts here -->
                    <div class="content-bar">
                        <div class="content-title">Next of Kin Information</div>
                        <div class="details">
                            <form method="post" action="submit_family_info.php">
                                <?php include 'fetch_family_info.php'; ?>
                                <label for="firstname">First Name: </label>
                                <input type="text" id="firstname" name="firstname" value="<?php echo $firstname; ?>">
                                <br><br>

                                <label for="surname">Surname: </label>
                                <input type="text" id="surname" name="surname" value="<?php echo $surname; ?>">
                                <br><br>

                                <label for="nationality">Nationality: </label>
                                <input type="text" id="nationality" name="nationality" value="<?php echo $nationality; ?>">
                                <br><br>

                                <label for="gender">Gender: </label>
                                <select name="gender" id="gender">
                                    <option value="" disabled selected hidden></option>
                                    <option value="male" <?php if($gender == "male") echo "selected"; ?>>Male</option>
                                    <option value="female" <?php if($gender == "female") echo "selected"; ?>>Female</option>
                                    <option value="other" <?php if($gender == "other") echo "selected"; ?>>Other</option>
                                </select>
                                <br><br>

                                <label for="relation">Relation to Applicant: </label>
                                <select name="relation" id="relation">
                                    <option value="" disabled selected hidden></option>
                                    <option value="father" <?php if($relation == "father") echo "selected"; ?>>Father</option>
                                    <option value="mother" <?php if($relation == "mother") echo "selected"; ?>>Mother</option>
                                    <option value="sibling" <?php if($relation == "sibling") echo "selected"; ?>>Sibling</option>
                                    <option value="legal_guardian" <?php if($relation == "legal_guardian") echo "selected"; ?>>Legal Guardian</option>
                                    <option value="spouse" <?php if($relation == "spouse") echo "selected"; ?>>Spouse</option>
                                    <option value="aunt_uncle" <?php if($relation == "aunt_uncle") echo "selected"; ?>>Aunt/Uncle</option>
                                    <option value="grandparent" <?php if($relation == "grandparent") echo "selected"; ?>>Grandparent</option>
                                    <option value="cousin" <?php if($relation == "cousin") echo "selected"; ?>>Cousin</option>
                                    <option value="ex_spouse" <?php if($relation == "ex_spouse") echo "selected"; ?>>Ex-Spouse</option>
                                </select>
                                <br><br>

                                <label for="address">Home Address: </label>
                                <input type="text" id="address" name="address" value="<?php echo $address; ?>">
                                <br><br>

                                <label for="phone">Phone Number: </label>
                                <input type="tel" id="phone" name="phone" value="<?php echo $phone; ?>">
                                <br><br>

                                <label for="email">Email: </label>
                                <input type="email" id="email" name="email" value="<?php echo $email; ?>">
                                <br><br>

                                <label for="postcode">Postal Code: </label>
                                <input type="text" id="postcode" name="postcode" value="<?php echo $postcode; ?>">
                                <br><br>

                                <input type="submit" id="submit" name="submit" value="Submit">
                                <br><br>

                            </form>
                        </div>
            
                    </div>
                    <!-- personal information bar ends here -->
                    
                </div>
            </div>
            <!-- page content ends here -->

        </div>

        

    </body>
</html>