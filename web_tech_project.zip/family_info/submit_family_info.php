<?php
session_start();

// Include database connection
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the session
$username = $_SESSION["username"];

// Retrieve form data
$firstname = $_POST['firstname'];
$surname = $_POST['surname'];
$nationality = $_POST['nationality'];
$gender = $_POST['gender'];
$relation = $_POST['relation'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$postcode = $_POST['postcode'];

// Check if applicant_id exists in proj_nextOfKin
$stmt_check = $conn->prepare("SELECT applicant_id FROM proj_nextOfKin WHERE applicant_id = (SELECT id FROM proj_applicant WHERE username=?)");
$stmt_check->bind_param("s", $username);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    // Update next of kin information
    $stmt_update = $conn->prepare("UPDATE proj_nextOfKin SET first_name=?, surname=?, nationality=?, gender=?, relation=?, address=?, phone=?, email=?, postcode=? WHERE applicant_id=(SELECT id FROM proj_applicant WHERE username=?)");
    $stmt_update->bind_param("ssssssssss", $firstname, $surname, $nationality, $gender, $relation, $address, $phone, $email, $postcode, $username);

    if ($stmt_update->execute()) {
        $message = "Next of kin information updated successfully.";
    } else {
        $message = "Error updating next of kin information: " . $stmt_update->error;
    }

    $stmt_update->close();
} else {
    // Insert new row with applicant_id
    $stmt_insert = $conn->prepare("INSERT INTO proj_nextOfKin (applicant_id, first_name, surname, nationality, gender, relation, address, phone, email, postcode) VALUES ((SELECT id FROM proj_applicant WHERE username=?), ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt_insert->bind_param("ssssssssss", $username, $firstname, $surname, $nationality, $gender, $relation, $address, $phone, $email, $postcode);

    if ($stmt_insert->execute()) {
        $message = "Next of kin information submitted successfully.";
    } else {
        $message = "Error inserting next of kin information: " . $stmt_insert->error;
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();

header("Location: family_form.php?message=" . urlencode($message));
exit();
?>
