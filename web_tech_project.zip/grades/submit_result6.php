<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Get form data
$level6 = $_POST["level6"];
$subject6 = $_POST["subject6"];
$grade6 = $_POST["grade6"];

// Get applicant ID
$applicant_id = "";
$stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
$stmt_applicant_id->bind_param("s", $username);
$stmt_applicant_id->execute();
$result_applicant_id = $stmt_applicant_id->get_result();

if ($result_applicant_id->num_rows > 0) {
    $row = $result_applicant_id->fetch_assoc();
    $applicant_id = $row['id'];
}

$stmt_applicant_id->close();
$message6 = "";

// Check if applicant ID already exists
$stmt_check = $conn->prepare("SELECT id FROM proj_applicant_grades WHERE applicant_id = ?");
$stmt_check->bind_param("i", $applicant_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    // Update existing row
    $stmt_update = $conn->prepare("UPDATE proj_applicant_grades SET level6=?, subject6=?, grade6=? WHERE applicant_id = ?");
    $stmt_update->bind_param("sssi", $level6, $subject6, $grade6, $applicant_id);

    if ($stmt_update->execute()) {
        $message6 = "Updated successfully.";
    } else {
        $message6 = "Error updating: " . $stmt_update->error;
    }

    $stmt_update->close();
} else {
    // Insert new row
    $stmt_insert = $conn->prepare("INSERT INTO proj_applicant_grades (applicant_id, level6, subject6, grade6) VALUES (?, ?, ?, ?)");
    $stmt_insert->bind_param("isss", $applicant_id, $level6, $subject6, $grade6);

    if ($stmt_insert->execute()) {
        $message6 = "Submitted successfully.";
    } else {
        $message6 = "Error inserting: " . $stmt_insert->error;
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();

header("Location: secondary_education.php?message6=" . urlencode($message6));
exit();
?>
