<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];
$message = isset($_GET['message']) ? $_GET['message'] : '';
$message2 = isset($_GET['message2']) ? $_GET['message2'] : '';
$message3 = isset($_GET['message3']) ? $_GET['message3'] : '';
$message4 = isset($_GET['message4']) ? $_GET['message4'] : '';
$message5 = isset($_GET['message5']) ? $_GET['message5'] : '';
$message6 = isset($_GET['message6']) ? $_GET['message6'] : '';
$message7 = isset($_GET['message7']) ? $_GET['message7'] : '';
$message8 = isset($_GET['message8']) ? $_GET['message8'] : '';
$message9 = isset($_GET['message9']) ? $_GET['message9'] : '';
$message10 = isset($_GET['message10']) ? $_GET['message10'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <link rel="stylesheet" href="../styles/personalstyles.css">
    <title>Secondary Education</title>
</head>

<style>
    table tr, td, th {
        padding-left: 5px;
        padding-right: 5px;
    }
</style>

<body>
<div class="wrapper">
    <!-- navigation bar starts here -->
    <div class="sidebar">
        <h2>UB Online Application</h2>
        <ul>
            <li><a href="../home/stud_home.php"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
            <li><a href="../personal_info/personal_information_form.php"><i class="fas fa-user"></i><p class="text">Personal Information</p></a></li>
            <li><a href="../family_info/family_form.php"><i class="fas fa-users"></i><p class="text">Next of Kin</p></a></li>
            <li><a href="../study_choices/study_choices.php"><i class="fas fa-graduation-cap"></i><p class="text">Study Choices</p></a></li>
            <li class="active"><a href="../grades/secondary_education.php"><i class="fas fa-school"></i><p class="text">Secondary Education</p></a></li>
            <li><a href="../uploadTable/uploadTable.php"><i class="fas fa-id-card"></i><p class="text">Documentation</p></a></li>
            <li><a href="../submit/submit_application.php"><i class="fas fa-check"></i><p class="text">Submit Application</p></a></li>
        </ul>
    </div>
    <!-- navigation bar ends here -->

    <!-- page contents start here -->
    <div class="main-content">
        <div class="header">
            <div class="text">Welcome to the UB Portal</div>
            <div class="bottom-btn">
                <a href="#"><i class="fas fa-bell"></i></a>
                <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="info">
            <!-- Secondary Education information bar starts here-->
            <div class="content-bar">
                <div class="content-title">Secondary Education</div>
                <div class="details">
                    <form method="post" action="submit_result1.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>
                                    <select name="level1" id="level1">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject1" id="subject1">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade1" id="grade1">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result2.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>
                                    <select name="level2" id="level2">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level2.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject2" id="subject2">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject2.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade2" id="grade2">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade2.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message2</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result3.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>
                                    <select name="level3" id="level3">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level3.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject3" id="subject3">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject3.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade3" id="grade3">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade3.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message3</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result4.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>
                                    <select name="level4" id="level4">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level4.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject4" id="subject4">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject4.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade4" id="grade4">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade4.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message4</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result5.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>
                                    <select name="level5" id="level5">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level5.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject5" id="subject5">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject5.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade5" id="grade5">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade5.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message5</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result6.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>
                                    <select name="level6" id="level6">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level6.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject6" id="subject6">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject6.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade6" id="grade6">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade6.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message6</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result7.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>7</td>
                                <td>
                                    <select name="level7" id="level7">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level7.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject7" id="subject7">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject7.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade7" id="grade7">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade7.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message7</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result8.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>8</td>
                                <td>
                                    <select name="level8" id="level8">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level8.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject8" id="subject8">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject8.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade8" id="grade8">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade8.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message8</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <form method="post" action="submit_result9.php">
                        <table>
                            <tr>
                                <td></td>
                                <th>Course Level</th>
                                <th>Subject</th>
                                <th>Grade</th>
                            </tr>
                            <tr>
                                <td>9</td>
                                <td>
                                    <select name="level9" id="level9">
                                        <option value="" disabled selected hidden></option>
                                            <?php include 'fetch_level9.php'; ?><?php echo $level1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="subject9" id="subject9">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_subject9.php'; ?><?php echo $subject1; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="grade9" id="grade9">
                                        <option value="" disabled selected hidden></option>
                                        <?php include 'fetch_grade9.php'; ?><?php echo $grade1; ?>
                                    </select>
                                </td>
                                <td width="200px">
                                    <input type="submit" id="submit" name="submit" value="Submit">
                                </td>
                                <td>
                                    <?php echo "<p>$message9</p>"; ?>
                                </td>
                            </tr>
                        </table>
                    </form>
                    <br><br>

                    <form method="post" action="save_points.php">
                        <input type="submit" id="submit" name="submit" value="Generate Points">
                        <?php echo "<p>$message10</p>"; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Page contents end here -->
</div>
</body>
</html>
