<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Get applicant ID
$applicant_id = "";
$stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
$stmt_applicant_id->bind_param("s", $username);
$stmt_applicant_id->execute();
$result_applicant_id = $stmt_applicant_id->get_result();

if ($result_applicant_id->num_rows > 0) {
    $row = $result_applicant_id->fetch_assoc();
    $applicant_id = $row['id'];
}

$stmt_applicant_id->close();

// Function to calculate points
function calculatePoints($grade) {
    switch ($grade) {
        case "A*":
            return 8;
        case "A":
            return 8;
        case "B":
            return 7;
        case "C":
            return 6;
        case "D":
            return 5;
        case "E":
            return 4;
        default:
            return 0; // Default value if grade not found
    }
}

// Process grades and calculate total points
$totalPoints = 0;
for ($i = 1; $i <= 9; $i++) {
    // Fetch grade from the database
    $column = "grade$i";
    $stmt = $conn->prepare("SELECT $column FROM proj_applicant_grades WHERE applicant_id = ?");
    $stmt->bind_param("i", $applicant_id);
    $stmt->execute();
    $stmt->bind_result($db_grade);
    $stmt->fetch();
    $stmt->close();

    // If grade exists in the database, use it, otherwise use an empty string
    $grade = isset($db_grade) ? $db_grade : '';

    // Calculate points based on the fetched grade
    $totalPoints += calculatePoints($grade);
}

// Save points in the database
$sql = "UPDATE proj_applicant SET points = $totalPoints WHERE username = '$username'";

$message10 = "";

if ($conn->query($sql) === TRUE) {
    $message10 = "Points saved successfully!";
} else {
    $message10 = "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
header("Location: secondary_education.php?message10=" . urlencode($message10));
exit();
?>
