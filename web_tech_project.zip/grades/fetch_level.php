<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Get applicant ID
$applicant_id = "";
$stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
$stmt_applicant_id->bind_param("s", $username);
$stmt_applicant_id->execute();
$result_applicant_id = $stmt_applicant_id->get_result();

if ($result_applicant_id->num_rows > 0) {
    $row = $result_applicant_id->fetch_assoc();
    $applicant_id = $row['id'];
}

$stmt_applicant_id->close();

// Get level1 from proj_applicant_grades
$sql_level1 = "SELECT level1 FROM proj_applicant_grades WHERE applicant_id = ?";
$stmt_level1 = $conn->prepare($sql_level1);
$stmt_level1->bind_param("i", $applicant_id);
$stmt_level1->execute();
$result_level1 = $stmt_level1->get_result();

$level1 = '';

if ($result_level1->num_rows > 0) {
    $row = $result_level1->fetch_assoc();
    $grade1 = $row['level1'];
}

// Fetch level from proj_secondary_levels
$sql = "SELECT DISTINCT level FROM proj_secondary_levels";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $level = $row["level"];
        $selected = ($level == $grade1) ? "selected" : "";
        echo "<option value='" . $row["level"] . "' $selected>" . $row["level"] . "</option>";
    }
} else {
    echo "<option value='' disabled>No course levels available</option>";
}

$conn->close();
?>
