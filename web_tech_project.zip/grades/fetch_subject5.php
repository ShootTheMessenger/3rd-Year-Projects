<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Get applicant ID
$applicant_id = "";
$stmt_applicant_id = $conn->prepare("SELECT id FROM proj_applicant WHERE username = ?");
$stmt_applicant_id->bind_param("s", $username);
$stmt_applicant_id->execute();
$result_applicant_id = $stmt_applicant_id->get_result();

if ($result_applicant_id->num_rows > 0) {
    $row = $result_applicant_id->fetch_assoc();
    $applicant_id = $row['id'];
}

$stmt_applicant_id->close();

// Get subject1 from proj_applicant_grades
$sql_subject1 = "SELECT subject5 FROM proj_applicant_grades WHERE applicant_id = ?";
$stmt_subject1 = $conn->prepare($sql_subject1);
$stmt_subject1->bind_param("i", $applicant_id);
$stmt_subject1->execute();
$result_subject1 = $stmt_subject1->get_result();

$subject1 = '';

if ($result_subject1->num_rows > 0) {
    $row = $result_subject1->fetch_assoc();
    $subject1 = $row['subject5'];
}

// Fetch subjects from proj_secondary_subjects
$sql_subjects = "SELECT subject FROM proj_secondary_subjects";
$result_subjects = $conn->query($sql_subjects);

echo "<option value='' disabled>Select Subject</option>";

if ($result_subjects->num_rows > 0) {
    while ($row = $result_subjects->fetch_assoc()) {
        $subject = $row["subject"];
        $selected = ($subject == $subject1) ? "selected" : "";
        echo "<option value='" . $subject . "' $selected>" . $subject . "</option>";
    }
} else {
    echo "<option value='' disabled>No subjects available</option>";
}

$conn->close();
?>
