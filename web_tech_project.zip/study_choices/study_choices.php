<?php
$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
        <link rel="stylesheet" href="../styles/studystyles.css">
        <title>Study Choices</title>
    </head>

    <body>
        <div class="wrapper">

            <!-- navigation bar starts here -->
            <div class="sidebar">
                <h2>UB Online Application</h2>
                <ul>
                    <li><a href="../home/stud_home.php"><i class="fas fa-home"></i><p class="text">Home</p></a></li>
                    <li><a href="../personal_info/personal_information_form.php"><i class="fas fa-user"></i><p class="text">Personal Information</p></a></li>
                    <li><a href="../family_info/family_form.php"><i class="fas fa-users"></i><p class="text">Next of Kin</p></a></li>
                    <li class="active"><a href="../study_choices/study_choices.php"><i class="fas fa-graduation-cap"></i><p class="text">Study Choices</p></a></li>
                    <li><a href="../grades/secondary_education.php"><i class="fas fa-school"></i><p class="text">Secondary Education</p></a></li>
                    <li><a href="../uploadTable/uploadTable.php"><i class="fas fa-id-card"></i><p class="text">Documentation</p></a></li>
                    <li><a href="../submit/submit_application.php"><i class="fas fa-check"></i><p class="text">Submit Application</p></a></li>
                </ul>
            </div>
            <!-- navigation bar ends here -->

            <!-- page content starts here -->
            <div class="main-content">
                <div class="header">
                    <div class="text">Welcome to the UB Portal</div>
                    <div class="bottom-btn">
                        <a href="#"><i class="fas fa-bell"></i></a>
                        <a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>

                <div class="info">

                    <!-- personal information bar starts here -->
                    <div class="content-bar">
                        <div class="content-title">Study Choices</div>
                        <div class="details">
                            <form method="post" action="submit_choice1.php">
                                <label for="choice1">First Choice: </label>
                                <select name="choice1" id="choice1">
                                    <?php include 'fetch_choice1.php'; ?>
                                    <!--<option value="african_lang">African Languages & Literature</option>
                                    <option value="archaeolgy">Archaeology</option>
                                    <option value="chemistry">Chemistry</option>
                                    <option value="chinese">Chinese Studies</option>
                                    <option value="computer_science">Computer Science</option>
                                    <option value="criminal_justice">Criminal Justice</option>
                                    <option value="digital_media">Digital Media</option>
                                    <option value="economics">Economics</option>
                                    <option value="engineering">English</option>
                                    <option value="history">History</option>
                                    <option value="humanities">Humanities</option>
                                    <option value="music">Music Education</option>
                                    <option value="nursing">Nursing</option>
                                    <option value="primary_education">Primary Education</option>
                                    <option value="pharmacy">Pharmacy</option>
                                    <option value="physics">Physics</option>
                                    <option value="sports">Sport Science</option>-->
                                </select>
                                <input type="submit" id="submit" name="submit" value="Submit"><?php echo $message; ?>
                                <br><br>
                            </form>

                            <form method="post" action="submit_choice2.php">
                                <label for="choice2">Second Choice: </label>
                                <select name="choice2" id="choice2">
                                    <?php include 'fetch_choice2.php'; ?>
                                    <!--<option value="african_lang">African Languages & Literature</option>
                                    <option value="archaeolgy">Archaeology</option>
                                    <option value="chemistry">Chemistry</option>
                                    <option value="chinese">Chinese Studies</option>
                                    <option value="computer_science">Computer Science</option>
                                    <option value="criminal_justice">Criminal Justice</option>
                                    <option value="digital_media">Digital Media</option>
                                    <option value="economics">Economics</option>
                                    <option value="engineering">English</option>
                                    <option value="history">History</option>
                                    <option value="humanities">Humanities</option>
                                    <option value="music">Music Education</option>
                                    <option value="nursing">Nursing</option>
                                    <option value="primary_education">Primary Education</option>
                                    <option value="pharmacy">Pharmacy</option>
                                    <option value="physics">Physics</option>
                                    <option value="sports">Sport Science</option>-->
                                </select>

                                <input type="submit" id="submit" name="submit" value="Submit">
                                <br><br>
                            </form>
                        </div>
            
                    </div>
                    <!-- personal information bar ends here -->
                    
                </div>
            </div>
            <!-- page content ends here -->

        </div>

        

    </body>
</html>