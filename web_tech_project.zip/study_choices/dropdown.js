// Sample data for faculties, degrees, and courses
const faculties = ["Engineering", "Science", "Arts"];
const courses = ["Computer Science", "Mechanical Engineering", "Biology", "Psychology"];
const degreesByCourse = {
    "Computer Science": ["Bachelor", "Master", "PhD"],
    "Mechanical Engineering": ["Bachelor", "Master", "PhD"],
    "Biology": ["Bachelor", "Master", "PhD"],
    "Psychology": ["Bachelor", "Master", "PhD"]
};

// Function to create dropdowns in the table
function createDropdowns() {
    const facultyCells = document.querySelectorAll(".faculty");
    const degreeCells = document.querySelectorAll(".degree");
    const courseCells = document.querySelectorAll(".course");
    
    facultyCells.forEach(cell => {
        createDropdown(cell, faculties);
    });

    courseCells.forEach((cell, index) => {
        createCourseDropdown(cell, index);
    });

    // Update degrees when a course is selected
    courseCells.forEach((cell, index) => {
        cell.querySelector("select").addEventListener("change", function() {
            const selectedCourse = this.value;
            const degreeSelect = degreeCells[index].querySelector("select");
            const degrees = degreesByCourse[selectedCourse];
            updateDropdown(degreeSelect, degrees);
        });
    });
}

// Function to create a dropdown for faculties
function createDropdown(cell, options) {
    const select = document.createElement("select");

    

    options.forEach(option => {
        const optionElement = document.createElement("option");
        optionElement.text = option;
        optionElement.value = option;
        select.appendChild(optionElement);
    });

    cell.appendChild(select);
}

// Function to create a dropdown for courses
function createCourseDropdown(cell, index) {
    const select = document.createElement("select");

    // Create an invisible option
    const invisibleOption = document.createElement("option");
    invisibleOption.disabled = true;
    invisibleOption.selected = true;
    invisibleOption.hidden = true;
    select.appendChild(invisibleOption);

    courses.forEach(course => {
        const optionElement = document.createElement("option");
        optionElement.text = course;
        optionElement.value = course;
        select.appendChild(optionElement);
    });

    // Set a default value
    select.value = "";

    cell.appendChild(select);
  
    // Create a degree dropdown for the initial course
    const degreeCell = document.querySelectorAll(".degree")[index];
    createDegreeDropdown(degreeCell, []);
}

// Function to create a dropdown for degrees
function createDegreeDropdown(cell, options) {
    const select = document.createElement("select");

    // Create an invisible option
    const invisibleOption = document.createElement("option");
    invisibleOption.disabled = true;
    invisibleOption.selected = true;
    invisibleOption.hidden = true;
    select.appendChild(invisibleOption);

    options.forEach(option => {
        const optionElement = document.createElement("option");
        optionElement.text = option;
        optionElement.value = option;
        select.appendChild(optionElement);
    });

    cell.appendChild(select);
}

// Function to update dropdown options
function updateDropdown(select, options) {
    select.innerHTML = '';

    // Create an invisible option
    const invisibleOption = document.createElement("option");
    invisibleOption.disabled = true;
    invisibleOption.selected = true;
    invisibleOption.hidden = true;
    select.appendChild(invisibleOption);

    options.forEach(option => {
        const optionElement = document.createElement("option");
        optionElement.text = option;
        optionElement.value = option;
        select.appendChild(optionElement);
    });
}

// Call the function to create dropdowns
createDropdowns();