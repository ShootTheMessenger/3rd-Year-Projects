<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the session
$username = $_SESSION["username"];

$sql_courses = "SELECT course_name FROM proj_courses";
$result_courses = $conn->query($sql_courses);

$sql_subjects = "SELECT first_choice, second_choice FROM proj_applicant WHERE username = ?";
$stmt = $conn->prepare($sql_subjects);
$stmt->bind_param("s", $username);
$stmt->execute();
$result_subjects = $stmt->get_result();

$selected_courses = [];

if ($result_subjects->num_rows > 0) {
    $row = $result_subjects->fetch_assoc();
    $selected_courses[] = $row['first_choice'];
    $selected_courses[] = $row['second_choice'];
}

if ($result_courses->num_rows > 0) {
    while ($row = $result_courses->fetch_assoc()) {
        $course_name = $row["course_name"];
        $selected = (in_array($course_name, $selected_courses)) ? "selected" : "";
        echo "<option value='" . $course_name . "' $selected>" . $course_name . "</option>";
    }
} else {
    echo "<option value='' disabled>No courses available</option>";
}

$stmt->close();
$conn->close();
?>
