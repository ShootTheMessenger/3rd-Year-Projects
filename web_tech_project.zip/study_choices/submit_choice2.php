<?php
session_start();

$servername = "10.0.19.74";
$username = "mnd02742";
$password = "mnd02742";
$database = "db_mnd02742";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$choice2 = $_POST["choice2"];
$username = $_SESSION["username"];    

// Update first choice in proj_applicant table
$sql = "UPDATE proj_applicant SET second_choice = ? WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $choice2, $username);

$message = "";

if ($stmt->execute()) {
    $message="Second choice updated successfully.";
} else {
    $message="Error updating first choice: " . $conn->error;
}

$stmt->close();
$conn->close();

header("Location: study_choices.php");
exit();

?>
